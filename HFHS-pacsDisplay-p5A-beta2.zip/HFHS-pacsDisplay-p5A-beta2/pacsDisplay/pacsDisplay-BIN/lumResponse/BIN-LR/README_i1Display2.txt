The xRite i1Display 2 photometer is read using the
Argyll spotread.exe binary program that uses the
libsub library, libusb-1.0A.dll, to manage the USB channel.

The Argyll driver for the i1Display2 device must
be loaded in Windows before use.