This contains an updated gnuplot distribution
along with the 2008 version of getEDID.

Locating the LIB in this directory
is only to be kept for development
and the BIN-display distribution.

MJF
NOV-2013