In late 2006, 7 workstations for diagnostic interpretation
were deployed at Henry Ford Health System as a part of
service expansion. These workstations were configured with
four monitors (dual 3MP monochrome monitors and dual 20"
color LCD monitors). Advanced graphics cards were used
on the color monitors to support 3D analysis. The uLR
for these monitors shows excellant consistency as was
seen in an earlier project for the Dell 2001FP monitors.