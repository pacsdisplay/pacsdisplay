Dell 19" LCD monitors were used at Henry Ford Health System
in the second quarter of 2005 as a part of a large enterprise
upgrade of systems located in medical clinics. Approximately
1200 were deployed in locations where images  were  frequently
viewed using a PACS web client. This was the first deployment
of the pacsDisplay software which was loaded on the master
disk image for all systems. The loadLUT software was set
up using a calibration LUT based on one representative
system;
           uLR_DELL_1905FP_53U-173A_b.txt

Approximately 24 workstation were tested a month
after deployment by measuring the calibrated 256 step
grayscale response. The results supported the belief
that the response of these  monitors is very similar
and appropriate for calibration with a GENERIC LUT.

The library contains a GENERIC LUT built from a
the representative monitor above.
This monitor has been repeatedly tested to
ascertain whether significant changes occur over time.
This uLRstats application for computing the average
uLR was not available at the time of the original
enterprise deployment.