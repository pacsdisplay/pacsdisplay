Status as of version 4C release.

Log of LUT-Library contributions
 - number in parenthesis indicates the number
   of monitors with uLR measurements
 - A g appended to the number indicates that
   a generic LUT is present.

20070112, initial release by HFHS
  DELL_1900FP_(20)
  DELL_1901FP_(2)
  DELL_1905FP_(3g)
  DELL_1907FP_(1)
  DELL_1907FPV_(1)
  DELL_2001FP_(21g)
  DELL_2007FP_(10g)
  DELL_2405FPW_(1)
  SAMSUNG_403T_(4)
  SHARP_T2020_(2)

20070327, Added by HFHS
  DELL_2007WFP_(1g)
  DELL_1907FPV_(1g), made generic

20070712, Contributed by Mayo Clinic
  DELL_2407WFP_(2)
  DELL_2707WFP_(1)
  DELL_3007WFP_(16g)
  DELL_3007WFPHC_(1)

20081114, Added by HFHS
  DELL_2407WFP_(2)
  DELL_2408WFP_(3g)
  SHARP_LC65D64U

200910,23, Added by HFHS
  PLANAR_PX191
  PLANAR_PX212

20091215, Added by HFHS
  L200ME
  HP_LP2065_(2g)

20091217, Added by HFHS
  HP_LP2065_(2g)

20110218, Added by HFHS
  EA231WMi_(2g)
